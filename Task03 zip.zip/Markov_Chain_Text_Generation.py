
import random

class MarkovChainTextGenerator:
    def __init__(self):
        self.model = {}

    def train(self, text):
        words = text.split()
        for i in range(len(words) - 1):
            curr_word = words[i]
            next_word = words[i + 1]
            if curr_word not in self.model:
                self.model[curr_word] = []
            self.model[curr_word].append(next_word)

    def generate(self, start_word, num_words=50):
        if start_word not in self.model:
            return "Start word not in training data."
        result = [start_word]
        current_word = start_word
        for _ in range(num_words - 1):
            next_words = self.model.get(current_word, [])
            if not next_words:
                break
            current_word = random.choice(next_words)
            result.append(current_word)
        return ' '.join(result)

# Sample usage
if __name__ == "__main__":
    sample_text = (
        "Artificial intelligence is transforming the world. "
        "AI is everywhere, from voice assistants to autonomous cars. "
        "The future of technology is AI-driven innovation."
    )

    generator = MarkovChainTextGenerator()
    generator.train(sample_text)

    print("Generated Text:")
    print(generator.generate("Artificial"))
